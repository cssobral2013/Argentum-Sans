# Argentum Sans
Argentum Sans (Latin for "Silver") is a sans-serif geometric font forked from Montserrat version 5.001. This project was born following the two weight changes in 2017 on upstream fonts, so we created this font as a response. The first modifications are a lowercase l with a tail from alternate glyphs, and fixed some glyphs.

It supports the following blocks: Afrikaans, Baltic, Basic Latin, Catalan, Central European, Basic Cyrillic, Extended Cyrillic (plus localized forms for Bulgarian, Serbian, Macedonian, and others), Dutch, Esperanto, Euro, Greek, Igbo Onwu, Romanian, Turkish, Vietnamese, and Western European (1,200+ glyphs per face).

See FONTLOG.txt for full list of changes and other information regarding this font.
